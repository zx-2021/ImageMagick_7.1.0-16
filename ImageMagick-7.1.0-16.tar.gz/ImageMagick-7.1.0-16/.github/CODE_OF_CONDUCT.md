# ImageMagick Code of Conduct

Strive to give back to the ImageMagick community more than you take and be excellent to each other.
